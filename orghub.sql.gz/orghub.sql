-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2024 at 03:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orghub`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `AdminID` int(11) DEFAULT NULL,
  `AdminName` varchar(50) DEFAULT NULL,
  `AdminEmail` varchar(100) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `AdminID`, `AdminName`, `AdminEmail`, `Password`) VALUES
(1, 1001, 'Isabel Santiago', 'isabels@gmai.com', '1234'),
(2, 1002, 'Martin Castillo', 'martinc@gmail.com', '1234'),
(3, 1003, 'Erika Tan', 'erikat@gmail.com', '1234'),
(4, 1004, 'Angela Morales', 'angelam@gmail.com', '1234'),
(5, 1005, 'Julian Diaz', 'jualiand@gmail.com', '1234'),
(6, 1006, 'Ivan Villareal', 'ivanv@gmail.com', '1234'),
(7, 1007, 'Bianca Marquez', 'biacam@gmail.com', '1234'),
(8, 1008, 'Lorena Bautista', 'lorenam@gmail.com', '1234'),
(9, 1009, 'Joana Torres', 'joanat@gmail.com', '1234'),
(10, 1010, 'Mark Villanueva', 'markv@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `announcement_title` varchar(255) DEFAULT NULL,
  `short_desc` text DEFAULT NULL,
  `long_desc` text DEFAULT NULL,
  `event_details` text DEFAULT NULL,
  `event_reg` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `org_id`, `announcement_title`, `short_desc`, `long_desc`, `event_details`, `event_reg`) VALUES
(1, 1, 'Tree Planting Event', 'Join us this Saturday for our annual tree planting at the campus eco-park. Let?s contribute to a greener environment! Volunteers needed.', 'Join us this Saturday for our annual tree planting at the campus eco-park. Let?s contribute to a greener environment! Volunteers needed.', '11/30/2024', '2024-11-30'),
(2, 2, 'Startup Bootcamp 2024', 'Learn from successful Filipino entrepreneurs and get insights on starting your own business. Register now for the 2-day bootcamp!', 'Learn from successful Filipino entrepreneurs and get insights on starting your own business. Register now for the 2-day bootcamp!', '12/1/2024', '2024-11-30'),
(3, 3, 'Open Call for Writers and Broadcasters', 'Are you passionate about the media? We?re looking for new members to join our news and broadcast teams. Apply now and be part of CMO!', 'Are you passionate about the media? We?re looking for new members to join our news and broadcast teams. Apply now and be part of CMO!', '12/2/2024', '2024-11-30'),
(4, 4, 'Free Yoga Class', 'Join our free yoga session this Friday at the campus gym. A perfect way to de-stress and stay fit during exams week!', 'Join our free yoga session this Friday at the campus gym. A perfect way to de-stress and stay fit during exams week!', '12/3/2024', '2024-11-30'),
(5, 5, 'Barangay Outreach Program', 'We?re looking for volunteers for our upcoming outreach at Barangay San Jose. Let?s make a difference in the lives of the children in this community.', 'We?re looking for volunteers for our upcoming outreach at Barangay San Jose. Let?s make a difference in the lives of the children in this community.', '12/4/2024', '2024-11-30'),
(6, 6, 'Free Laptop Repair Service', 'Having tech problems? Our team is offering free laptop diagnostics and minor repairs this Thursday at the IT Lab. First come, first served!', 'Having tech problems? Our team is offering free laptop diagnostics and minor repairs this Thursday at the IT Lab. First come, first served!', '12/5/2024', '2024-11-30'),
(7, 7, 'Business Pitch Contest', 'Do you have the next big idea? Join our Business Pitch Contest for a chance to win startup funding and mentorship from industry leaders!', 'Do you have the next big idea? Join our Business Pitch Contest for a chance to win startup funding and mentorship from industry leaders!', '12/6/2024', '2024-11-30'),
(8, 8, 'Beach Cleanup Drive', 'Let?s keep our coastlines clean! Volunteer for our beach cleanup this weekend at La Union. Transportation will be provided. Sign up today!', 'Let?s keep our coastlines clean! Volunteer for our beach cleanup this weekend at La Union. Transportation will be provided. Sign up today!', '12/7/2024', '2024-11-30'),
(9, 9, 'Book Donation Drive', 'We are collecting books for our community library project. Donate your old books and help spread the joy of reading to children in need!', 'We are collecting books for our community library project. Donate your old books and help spread the joy of reading to children in need!', '12/8/2024', '2024-11-30'),
(10, 10, 'Esports Tournament 2024', 'Are you ready to prove your skills? Register now for our annual Esports Tournament! We?re featuring popular games like Valorant, Dota 2, and Mobile Legends.', 'Are you ready to prove your skills? Register now for our annual Esports Tournament! We?re featuring popular games like Valorant, Dota 2, and Mobile Legends.', '12/9/2024', '2024-11-30');

-- --------------------------------------------------------

--
-- Table structure for table `announcement_approval`
--

CREATE TABLE `announcement_approval` (
  `id` int(11) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `announcement` text DEFAULT NULL,
  `approval_file` blob DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `status` enum('Approved','Pending','Declined') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement_approval`
--

INSERT INTO `announcement_approval` (`id`, `org_name`, `title`, `announcement`, `approval_file`, `date_submitted`, `status`) VALUES
(1, 'Sustainable Campus Initiative (SCI) ', 'Tree Planting Event', 'Join us this Saturday for our annual tree planting at the campus eco-park. Let?s contribute to a greener environment! Volunteers needed.', 0x6e756c6c, '2024-07-16 22:41:32', 'Pending'),
(2, 'Future Business Leaders Society (FBLS)', 'Startup Bootcamp 2024', 'Learn from successful Filipino entrepreneurs and get insights on starting your own business. Register now for the 2-day bootcamp!', 0x6e756c6c, '2024-10-10 20:41:52', 'Pending'),
(3, 'Campus Media Organization (CMO)', 'Open Call for Writers and Broadcasters', 'Are you passionate about the media? We?re looking for new members to join our news and broadcast teams. Apply now and be part of CMO!', 0x6e756c6c, '2024-12-03 22:42:04', 'Pending'),
(4, 'Health and Wellness ?Society (HWS)', 'Free Yoga Class', 'Join our free yoga session this Friday at the campus gym. A perfect way to de-stress and stay fit during exams week!', 0x6e756c6c, '2024-08-05 15:42:09', 'Pending'),
(5, 'Cultural Arts Society (CAS)', 'Barangay Outreach Program', 'We?re looking for volunteers for our upcoming outreach at Barangay San Jose. Let?s make a difference in the lives of the children in this community.', 0x6e756c6c, '2024-11-25 10:42:19', 'Pending'),
(6, 'Tech Support Group (TSG)', 'Free Laptop Repair Service', 'Having tech problems? Our team is offering free laptop diagnostics and minor repairs this Thursday at the IT Lab. First come, first served!', 0x6e756c6c, '2024-12-01 22:42:34', 'Pending'),
(7, 'Young Entrepreneurs Network (YEN)', 'Business Pitch Contest', 'Do you have the next big idea? Join our Business Pitch Contest for a chance to win startup funding and mentorship from industry leaders!', 0x6e756c6c, '2024-12-01 22:42:38', 'Pending'),
(8, 'Environmental Advocacy Group (EAG)', 'Beach Cleanup Drive', 'Let?s keep our coastlines clean! Volunteer for our beach cleanup this weekend at La Union. Transportation will be provided. Sign up today!', 0x6e756c6c, '2024-12-01 22:42:40', 'Pending'),
(9, 'Student Volunteers for Literacy (SVL)', 'Book Donation Drive', 'We are collecting books for our community library project. Donate your old books and help spread the joy of reading to children in need!', 0x6e756c6c, '2024-12-01 22:42:43', 'Pending'),
(10, 'Gaming and Esports Society (GES)', 'Esports Tournament 2024', 'Are you ready to prove your skills? Register now for our annual Esports Tournament! We?re featuring popular games like Valorant, Dota 2, and Mobile Legends.', 0x6e756c6c, '2024-09-18 22:42:46', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `handled_events`
--

CREATE TABLE `handled_events` (
  `id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_overview` text NOT NULL,
  `event_image1` blob NOT NULL,
  `event_image2` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `handled_events`
--

INSERT INTO `handled_events` (`id`, `org_id`, `event_title`, `event_overview`, `event_image1`, `event_image2`) VALUES
(1, 1, 'Eco-Challenge Week', 'A week-long challenge encouraging students to adopt sustainable habits. Participants can track their eco-friendly actions, such as biking instead of driving, reducing water usage, or using reusable containers.\r\n', '', ''),
(2, 1, 'Campus Clean-Up Day', 'A community event where students, faculty, and staff come together to clean up campus grounds and surrounding areas.', '', ''),
(3, 1, 'Sustainable Living Fair', 'A fair that showcases sustainable products, local eco-friendly businesses, and student-led sustainability projects.', '', ''),
(4, 2, 'Entrepreneurship Workshop Series', 'A series of hands-on workshops designed to equip students with essential entrepreneurial skills.\r\n', '', ''),
(5, 2, 'Networking Nights', 'Social events designed to connect students with industry professionals and fellow aspiring business leaders.', '', ''),
(6, 2, 'Mentorship Program Launch', 'A structured program pairing students with experienced mentors for guidance and support.', '', ''),
(7, 2, 'Business Case Competitions', 'A competitive event where teams tackle real-world business challenges posed by local companies.', '', ''),
(8, 2, 'Industry Insights Series', 'A series of events featuring guest speakers from various industries, sharing their expertise and experiences.', '', ''),
(14, 3, 'Media Skills Workshop Series', 'A series of workshops aimed at enhancing students\' skills in various media fields, including journalism, broadcasting, and digital content creation.\r\n', '', ''),
(15, 3, 'Campus Media Fair', 'An event showcasing the various media outlets available on campus, providing students with information on how to get involved.\r\n', '', ''),
(16, 3, 'Journalism Ethics Panel', 'A discussion event focused on the importance of ethics in journalism, featuring experienced journalists and faculty.', '', ''),
(17, 3, 'Podcasting Bootcamp', 'A hands-on workshop designed to teach students how to create, edit, and produce their own podcasts.', '', ''),
(18, 3, 'Media Critique Night', 'An event where students analyze and critique various media outputs, fostering critical thinking about media consumption and production.', '', ''),
(24, 4, 'Fitness Challenge Month', 'A month-long initiative encouraging students to participate in various physical activities to promote fitness and healthy competition.', '', ''),
(25, 4, 'Nutrition Workshop Series', 'A series of interactive workshops aimed at educating students about healthy eating habits and nutrition.', '', ''),
(26, 4, 'Mindfulness and Meditation Retreat', 'A one-day retreat focused on mindfulness practices to promote mental clarity and emotional well-being.', '', ''),
(27, 5, 'Philippine Arts Festival', 'A vibrant festival celebrating various forms of Philippine art, from visual arts to performing arts.\r\n', '', ''),
(28, 5, 'Cultural Workshops Series', 'Hands-on workshops aimed at teaching traditional Philippine arts and crafts.\r\n', '', ''),
(29, 5, 'Film Screening and Discussion', 'A film series showcasing Filipino cinema, followed by discussions on cultural themes and representations.', '', ''),
(30, 5, 'Cultural Exchange Day', 'An event fostering cultural exchange between Filipino and other cultural groups on campus.', '', ''),
(31, 5, 'Heritage Month Celebration', 'A month-long celebration of Philippine heritage, with events showcasing history, art, and culture.\r\n', '', ''),
(32, 6, 'Tech Help Workshops', 'A series of hands-on workshops designed to assist students and staff with common technical issues.', '', ''),
(33, 6, 'Tech Support Clinics', 'Drop-in sessions where students and staff can receive personalized technical assistance.', '', ''),
(34, 6, 'Digital Literacy Campaign', 'An initiative to promote digital literacy across campus, focusing on essential tech skills.', '', ''),
(35, 6, 'Hackathon', 'An event where students collaborate to solve tech-related challenges and create innovative solutions.', '', ''),
(36, 6, 'Tech Q&A Panels', 'Panel discussions featuring IT professionals answering common tech-related questions and concerns.', '', ''),
(37, 7, 'Startup Pitch Competition', 'Aspiring entrepreneurs present their business ideas to a panel of judges, including local business owners and investors. Participants receive feedback on their pitches and the chance to win prizes such as mentorship sessions, startup funding, or coworking space memberships.', '', ''),
(38, 7, 'Entrepreneurship Workshop Series', 'A series of hands-on workshops focused on essential business skills such as marketing, financial planning, and digital branding. Each session features expert speakers and interactive activities to help participants apply what they learn.', '', ''),
(39, 7, 'Networking Night with Local Startups', 'An informal event where students can meet and network with local entrepreneurs and startups. This event aims to foster connections, share experiences, and explore internship or collaboration opportunities.', '', ''),
(40, 8, 'Eco Awareness Campaign', 'A campaign aimed at educating students and the community about key environmental issues and sustainable practices.', '', ''),
(41, 8, 'Waste Reduction Initiatives', 'Programs focused on minimizing waste through education and practical actions.', '', ''),
(42, 8, 'Biodiversity Conservation Projects', 'Initiatives aimed at preserving local ecosystems and promoting biodiversity.', '', ''),
(43, 8, 'Climate Action Workshops', 'Workshops focused on climate change solutions and actions individuals can take.', '', ''),
(44, 8, 'Environmental Film Festival', 'A screening event featuring films and documentaries focused on environmental issues and activism.', '', ''),
(45, 9, 'Reading Programs.', 'Regular sessions where student volunteers read to children in underserved communities to foster a love for reading.', '', ''),
(46, 9, 'Book Drives', 'Initiatives to collect new and gently used books for children in need.', '', ''),
(47, 9, 'Tutoring Sessions', 'One-on-one or small group tutoring for children struggling with reading and literacy skills.', '', ''),
(48, 9, 'Literacy Workshops for Parents', 'Workshops designed to educate parents on supporting their children\'s literacy development at home.', '', ''),
(49, 9, 'Literacy Awareness Campaigns', 'Initiatives to raise awareness about the importance of literacy and its impact on children’s futures.', '', ''),
(50, 10, 'Esports Tournament 2024', 'Compete against your peers in our annual Esports Tournament! Showcase your skills in popular games like Valorant, Dota 2, and Mobile Legends, with prizes for the top teams.', '', ''),
(51, 10, 'Game Development Workshop Series.', 'A hands-on workshop series for students interested in game design and development. Learn the fundamentals from industry professionals and create your own game prototype.', '', ''),
(52, 10, 'Streaming and Broadcasting Night.', 'Join us for an exciting evening dedicated to game streaming! Learn the ins and outs of broadcasting your gameplay and engaging with viewers.', '', ''),
(53, 10, 'Gaming Industry Discussion Panels.', 'Explore the gaming industry through insightful discussions featuring game developers, esports professionals, and content creators.', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `org_id` int(11) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `org_acronym` varchar(20) DEFAULT NULL,
  `org_email` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`org_id`, `org_name`, `org_acronym`, `org_email`, `description`) VALUES
(1, 'Sustainable Campus Initiative (SCI) ', 'SCI', 'sci@gmail.com', 'Dedicated to promoting sustainability on campus, SCI organizes events and projects focused on reducing the university’s carbon footprint and encouraging eco-friendly habits among students.\r\n'),
(2, 'Future Business Leaders Society (FBLS)', 'FBLS', 'fbls@gmail.com', 'Aimed at grooming future entrepreneurs and business leaders, FBLS offers workshops, mentorship, and networking opportunities for students interested in business and leadership.'),
(3, 'Campus Media Organization (CMO)', 'CMO', 'cmo@gmail.com', 'The official media arm of the university, CMO manages the campus newspaper, radio, and online platforms. It provides students with hands-on experience in journalism, broadcasting, and digital media.'),
(4, 'Health and Wellness  Society (HWS)', 'HWS', 'hws@gmail.com', 'This organization promotes the physical, mental, and emotional well-being of students through workshops, fitness activities, and counseling services.'),
(5, 'Cultural Arts Society (CAS)', 'CAS', 'cas@gmail.com', 'CAS celebrates Philippine culture and arts, organizing events like performances, art exhibits, and cultural workshops to showcase the talents of students and preserve local traditions.\r\n'),
(6, 'Tech Support Group (TSG)', 'TSG', 'tsg@gmail.com', 'TSG provides technical assistance to students and staff, helping with issues related to computers, software, and other IT needs within the university.'),
(7, 'Young Entrepreneurs Network (YEN)', 'YEN', 'yen@gmail.com', 'YEN helps aspiring student entrepreneurs develop business skills through mentorship, business plan competitions, and networking events with local startups and established businesses.'),
(8, 'Environmental Advocacy Group (EAG)', 'EAG', 'eag@gmail.com', 'EAG raises awareness about environmental issues and works on initiatives such as waste reduction, biodiversity conservation, and climate change action in the university and surrounding communities.'),
(9, 'Student Volunteers for Literacy (SVL)', 'SVL', 'svl@gmail.com', 'SVL promotes literacy by organizing reading programs, book drives, and tutoring sessions for underprivileged children in nearby communities.'),
(10, 'Gaming and Esports Society (GES)', 'GES', 'ges@gmail.com', 'GES provides a space for students who are passionate about video games and esports. The group organizes gaming tournaments, streaming events, and discussions on the gaming industry.');

-- --------------------------------------------------------

--
-- Table structure for table `org_commitee`
--

CREATE TABLE `org_commitee` (
  `id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `commitee_name` varchar(255) DEFAULT NULL,
  `comm_shortDesc` text DEFAULT NULL,
  `comm_longDesc` text DEFAULT NULL,
  `comm_reg` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `org_commitee`
--

INSERT INTO `org_commitee` (`id`, `org_id`, `commitee_name`, `comm_shortDesc`, `comm_longDesc`, `comm_reg`) VALUES
(1, 1, 'Campus Cleanups\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(2, 1, 'Recycling Program', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(3, 1, 'Renewable Energy Projects', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(4, 1, 'Green Education Campaign', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(5, 1, 'External Partnerships', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(6, 2, 'Entrepreneurship', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(7, 2, 'Leadership Development', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(8, 2, 'Events and Conferences\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(9, 2, 'Finance and Sponsorships', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(10, 2, 'Networking and Outreach\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(11, 3, 'News Writing and Journalism', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(12, 3, 'Radio and Broadcasting', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(13, 3, 'Social Media Management', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(14, 3, 'Video Production', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(15, 3, 'Photography and Design\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(16, 4, 'Mental Health Awareness\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(17, 4, 'Physical Fitness', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(18, 4, 'Nutrition and Diet', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(19, 4, 'Counseling Support', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(20, 4, 'Wellness Events', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(21, 5, 'Dance and Music', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(22, 5, 'Theater and Performance Arts', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(23, 5, 'Visual Arts', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(24, 5, 'Cultural Heritage Promotion\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(25, 5, 'Events and Exhibits', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(26, 6, 'Hardware Support', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(27, 6, 'Software Support', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(28, 6, 'IT Workshops', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(29, 6, 'Network Maintenance\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(30, 6, 'Help Desk Services', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(31, 7, 'Business Plan Development', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(32, 7, 'Pitch Competitions', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(33, 7, 'Networking Events', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(34, 7, 'Mentorship Program.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(35, 7, 'Sponsorship and Fundraising', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(36, 8, 'Climate Action Projects.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(37, 8, 'Biodiversity Conservation', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(38, 8, 'Waste Management Initiatives.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(39, 8, 'Awareness Campaigns.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(40, 8, 'External Collaborations.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(41, 9, 'Book Drives.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(42, 9, 'Literacy Tutoring', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(43, 9, 'Reading Programs.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(44, 9, 'Community Outreach.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(45, 9, 'Event Planning.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(46, 10, 'Tournament Organization\r\n', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(47, 10, 'Game Development.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(48, 10, 'Streaming and Broadcasting.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(49, 10, 'Competitive Teams.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01'),
(50, 10, 'Community Engagement.', 'An organization is a structured group of people working together, with defined roles and responsibilities, to achieve specific goals, such as in businesses, non-profits, governments, or schools.', 'An organization is a structured group of people working together to achieve specific goals or objectives. It can exist in various forms, including businesses, non-profits, government entities, schools, or clubs, and typically functions through a hierarchy of roles and responsibilities', '2024-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `org_contact`
--

CREATE TABLE `org_contact` (
  `id` int(11) NOT NULL,
  `org_email` varchar(50) NOT NULL,
  `fb_link` varchar(100) NOT NULL,
  `org_office` varchar(2083) NOT NULL,
  `org_sched` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `org_contact`
--

INSERT INTO `org_contact` (`id`, `org_email`, `fb_link`, `org_office`, `org_sched`) VALUES
(1, 'sci@gmail.com', 'https://www.facebook.com/unique.page.name12345678', 'bautista bldg.', '2024-12-01 22:27:30'),
(2, 'fbls@gmail.com', 'https://www.facebook.com/unique.page.name12345679', 'bautista bldg.', '2024-12-01 22:27:37'),
(3, 'cmo@gmail.com', 'https://www.facebook.com/unique.page.name12345680', 'bautista bldg.', '2024-12-01 22:27:43'),
(4, 'hws@gmail.com', 'https://www.facebook.com/unique.page.name12345681', 'bautista bldg.', '2024-12-01 22:27:46'),
(5, 'cas@gmail.com', 'https://www.facebook.com/unique.page.name12345682', 'bautista bldg.', '2024-12-01 22:27:49'),
(6, 'tsg@gmail.com', 'https://www.facebook.com/unique.page.name12345683', 'bautista bldg.', '2024-12-01 22:27:52'),
(7, 'yen@gmail.com', 'https://www.facebook.com/unique.page.name12345684', 'bautista bldg.', '2024-12-01 22:27:55'),
(8, 'eag@gmail.com', 'https://www.facebook.com/unique.page.name12345685', 'bautista bldg.', '2024-12-01 22:27:58'),
(9, 'svl@gmail.com', 'https://www.facebook.com/unique.page.name12345686', 'bautista bldg.', '2024-12-01 22:28:00'),
(10, 'ges@gmail.com', 'https://www.facebook.com/unique.page.name12345687', 'bautista bldg.', '2024-12-01 22:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `org_member`
--

CREATE TABLE `org_member` (
  `member_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `org_role` varchar(50) DEFAULT NULL,
  `member_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `org_member`
--

INSERT INTO `org_member` (`member_id`, `org_id`, `org_role`, `member_name`) VALUES
(1001, 1, 'President', 'Isabel Santiago'),
(1002, 1, 'Vice-President', 'Marco Santos'),
(1003, 1, 'Secretary', 'Denise Lopez'),
(1004, 1, 'Treasurer', 'Jerome Ferrer'),
(2001, 2, 'President', 'Martin Castillo'),
(2002, 2, 'Vice-President', 'Beatrice Cruz'),
(2003, 2, 'Secretary', 'Clarisse Vergara'),
(2004, 2, 'Treasurer', 'Paolo Mendoza'),
(3001, 3, 'President', 'Erika Tan'),
(3002, 3, 'Vice-President', '?Luis Cruz'),
(3003, 3, 'Secretary', 'Hannah Uy'),
(3004, 3, 'Treasurer', 'Mark Bautista'),
(4001, 4, 'President', '?Angela Morales'),
(4002, 4, 'Vice-President', 'Kevin Ong'),
(4003, 4, 'Secretary', 'Fiona Villanueva'),
(4004, 4, 'Treasurer', '?Luke Garcia'),
(5001, 5, 'President', 'Julian Diaz'),
(5002, 5, 'Vice-President', 'Catherine Fajardo'),
(5003, 5, 'Secretary', 'Andrea Lim'),
(5004, 5, 'Treasurer', 'Richard Gutierrez'),
(6001, 6, 'President', 'Ivan Villareal'),
(6002, 6, 'Vice-President', 'Gabriel Cruz'),
(6003, 6, 'Secretary', 'Chelsea Tan'),
(6004, 6, 'Treasurer', 'Allan Lim'),
(7001, 7, 'President', 'Bianca Marquez'),
(7002, 7, 'Vice-President', 'Rafael Cruz'),
(7003, 7, 'Secretary', 'Carla Rivera'),
(7004, 7, 'Treasurer', 'Leo Morales'),
(8001, 8, 'President', 'Lorena Bautista'),
(8002, 8, 'Vice-President', 'Alex Cruz'),
(8003, 8, 'Secretary', 'Michelle Ong'),
(8004, 8, 'Treasurer', 'Fred Ramos'),
(9001, 9, 'President', 'Joana Torres'),
(9002, 9, 'Vice-President', 'Rico Sanchez'),
(9003, 9, 'Secretary', 'Jean Lim'),
(9004, 9, 'Treasurer', 'Andrew De la Cruz'),
(1101, 10, 'President', 'Mark Villanueva'),
(1102, 10, 'Vice-President', 'Janelle Cruz'),
(1103, 10, 'Secretary', 'Vincent Ong'),
(1104, 10, 'Treasurer', 'Lucas Tan');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` enum('F','M') DEFAULT NULL,
  `birthday` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `StudentID`, `name`, `email`, `gender`, `birthday`) VALUES
(1, 24, 'Wilfrid Dockrill', 'wdockrill0@bluehost.com', '', '0000-00-00'),
(2, 24, 'Salvatore Cleminshaw', 'scleminshaw1@typepad.com', '', '0000-00-00'),
(3, 24, 'Freeman Game', 'fgame2@japanpost.jp', '', '0000-00-00'),
(4, 24, 'Lynnet Gullane', 'lgullane3@weebly.com', '', '0000-00-00'),
(5, 24, 'Catlaina Blaiklock', 'cblaiklock4@bloglovin.com', '', '0000-00-00'),
(6, 24, 'Shani Worsam', 'sworsam5@cloudflare.com', '', '0000-00-00'),
(7, 24, 'Carmon Meni', 'cmeni6@indiegogo.com', '', '0000-00-00'),
(8, 24, 'Tremaine Wigg', 'twigg7@dyndns.org', '', '0000-00-00'),
(9, 24, 'Diego Sheather', 'dsheather8@marriott.com', '', '0000-00-00'),
(10, 24, 'Care Butterly', 'cbutterly9@ifeng.com', '', '0000-00-00'),
(11, 24, 'Anne Canete', 'acanetea@senate.gov', '', '0000-00-00'),
(12, 24, 'Holli Kalewe', 'hkaleweb@webeden.co.uk', '', '0000-00-00'),
(13, 24, 'Kerstin McShea', 'kmcsheac@networksolutions.com', '', '0000-00-00'),
(14, 24, 'Riannon Jiruca', 'rjirucad@dmoz.org', '', '0000-00-00'),
(15, 24, 'Frederigo Silverlock', 'fsilverlocke@homestead.com', '', '0000-00-00'),
(16, 24, 'Margot Baudino', 'mbaudinof@omniture.com', '', '0000-00-00'),
(17, 24, 'Sheilakathryn Howgego', 'showgegog@cnet.com', '', '0000-00-00'),
(18, 24, 'Kile O\'Downe', 'kodowneh@jugem.jp', '', '0000-00-00'),
(19, 24, 'Ingram Dressel', 'idresseli@washington.edu', '', '0000-00-00'),
(20, 24, 'Dickie Pucker', 'dpuckerj@istockphoto.com', '', '0000-00-00'),
(21, 24, 'Rorke Ekell', 'rekellk@wiley.com', '', '0000-00-00'),
(22, 24, 'Terese Taffs', 'ttaffsl@pagesperso-orange.fr', '', '0000-00-00'),
(23, 24, 'Margarette Pearse', 'mpearsem@howstuffworks.com', '', '0000-00-00'),
(24, 24, 'Gil Girardetti', 'ggirardettin@goo.ne.jp', '', '0000-00-00'),
(25, 24, 'Gizela Sell', 'gsello@wikia.com', '', '0000-00-00'),
(26, 24, 'Opalina Kellar', 'okellarp@imgur.com', '', '0000-00-00'),
(27, 24, 'Elva Vaen', 'evaenq@slashdot.org', '', '0000-00-00'),
(28, 24, 'Marrilee Metzel', 'mmetzelr@stumbleupon.com', '', '0000-00-00'),
(29, 24, 'Danielle Prinett', 'dprinetts@nhs.uk', '', '0000-00-00'),
(30, 24, 'Maris Houliston', 'mhoulistont@slideshare.net', '', '0000-00-00'),
(31, 24, 'Esme Danilovich', 'edanilovichu@slate.com', '', '0000-00-00'),
(32, 24, 'Brigham Covell', 'bcovellv@comcast.net', '', '0000-00-00'),
(33, 24, 'Evelyn Pattillo', 'epattillow@soup.io', '', '0000-00-00'),
(34, 24, 'Lucilia Eick', 'leickx@oaic.gov.au', '', '0000-00-00'),
(35, 24, 'Mel Paintain', 'mpaintainy@baidu.com', '', '0000-00-00'),
(36, 24, 'Vlad Varga', 'vvargaz@google.com', '', '0000-00-00'),
(37, 24, 'Larisa Quan', 'lquan10@ihg.com', '', '0000-00-00'),
(38, 24, 'Torey Beamiss', 'tbeamiss11@home.pl', '', '0000-00-00'),
(39, 24, 'Louie Euston', 'leuston12@jalbum.net', '', '0000-00-00'),
(40, 24, 'Humphrey Sagerson', 'hsagerson13@fotki.com', '', '0000-00-00'),
(41, 24, 'Dill Enoksson', 'denoksson14@com.com', '', '0000-00-00'),
(42, 24, 'Viole Hugli', 'vhugli15@geocities.jp', '', '0000-00-00'),
(43, 24, 'Philip Sprigging', 'psprigging16@blinklist.com', '', '0000-00-00'),
(44, 24, 'Betta Wardle', 'bwardle17@prlog.org', '', '0000-00-00'),
(45, 24, 'Onfre Driscoll', 'odriscoll18@wordpress.com', '', '0000-00-00'),
(46, 24, 'Cosetta Footitt', 'cfootitt19@diigo.com', '', '0000-00-00'),
(47, 24, 'Eachelle Rawet', 'erawet1a@jiathis.com', '', '0000-00-00'),
(48, 24, 'Rodina Julien', 'rjulien1b@prlog.org', '', '0000-00-00'),
(49, 24, 'Nigel Betteriss', 'nbetteriss1c@google.ru', '', '0000-00-00'),
(50, 24, 'Trescha Ibbetson', 'tibbetson1d@ning.com', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `StudentID` varchar(50) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `StudentID`, `Name`, `Password`) VALUES
(1, '24-2301', 'Wilfrid Dockrill', 'aT9{B#p/?a)r'),
(2, '24-2302', 'Salvatore Cleminshaw', 'lX8.\"4C9TA'),
(3, '24-2303', 'Freeman Game', 'qR1.GcG$lQ\'?0IRo'),
(4, '24-2304', 'Lynnet Gullane', 'eN5{4}YLC\\%<II4'),
(5, '24-2305', 'Catlaina Blaiklock', 'gY6\\gyG`acS'),
(6, '24-2306', 'Shani Worsam', 'hM1))oT&\\md'),
(7, '24-2307', 'Carmon Meni', 'wG8{}EuFJOvl>BV'),
(8, '24-2308', 'Tremaine Wigg', 'iO4`g{qk<'),
(9, '24-2309', 'Diego Sheather', 'kV6)b/bE'),
(10, '24-2310', 'Care Butterly', 'cQ4~iyL0610M'),
(11, '24-2311', 'Anne Canete', 'tQ7*V.>='),
(12, '24-2312', 'Holli Kalewe', 'vS4\'@.I2,c0p\"'),
(13, '24-2313', 'Kerstin McShea', 'dV7<e>`0K=vYM*uX'),
(14, '24-2314', 'Riannon Jiruca', 'sM4$T1xDT`2'),
(15, '24-2315', 'Frederigo Silverlock', 'hJ7&ew,#gkEIRQ'),
(16, '24-2316', 'Margot Baudino', 'cO2{\\m&|=VnloYk0'),
(17, '24-2317', 'Sheilakathryn Howgego', 'mG0\'KZOEeXg'),
(18, '24-2318', 'Kile O\'Downe', 'aA5!Ypf{1+'),
(19, '24-2319', 'Ingram Dressel', 'tS3|lyh{j'),
(20, '24-2320', 'Dickie Pucker', 'iU8!&(4{cdG+'),
(21, '24-2321', 'Rorke Ekell', 'bW3}tQ`Y3H@g'),
(22, '24-2322', 'Terese Taffs', 'lR3~|c4XIA/_'),
(23, '24-2323', 'Margarette Pearse', 'vP0(wLROEVs4q<R');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement_approval`
--
ALTER TABLE `announcement_approval`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `handled_events`
--
ALTER TABLE `handled_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `org_commitee`
--
ALTER TABLE `org_commitee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `org_contact`
--
ALTER TABLE `org_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `announcement_approval`
--
ALTER TABLE `announcement_approval`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `handled_events`
--
ALTER TABLE `handled_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `org_commitee`
--
ALTER TABLE `org_commitee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
